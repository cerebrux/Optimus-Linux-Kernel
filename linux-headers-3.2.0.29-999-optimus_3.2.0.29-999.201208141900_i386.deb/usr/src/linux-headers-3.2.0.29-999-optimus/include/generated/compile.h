/* This file is auto generated, version 201208141900 */
/* SMP PREEMPT */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201208141900 SMP PREEMPT Tue Aug 14 20:40:54 EEST 2012"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "linux-turion-kernel"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
