#define UTS_RELEASE "3.2.12-999-optimus"
