/* This file is auto generated, version 201208121900 */
/* SMP PREEMPT */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201208121900 SMP PREEMPT Sun Aug 12 15:58:31 EEST 2012"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "optimus-kernel-corei7"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
